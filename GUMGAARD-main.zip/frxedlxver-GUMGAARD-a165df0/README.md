# GUMGAARD
A game about the last stand of the last tooth. Conceived amidst a polar vortex at Global Game Jam 2023.
